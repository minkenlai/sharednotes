# Shared notes

- `custom.sharednotes` connects Muse to the sharednotes REST service through its HTTPS API. It authenticates with the registered `api_key` credential and calls only the deployed Workers host.

- Helpers live in `~/workspace/custom-connectors/custom.sharednotes/bin/`. `notes.py` lists, reads, creates, updates and deletes notes.

## Connect

- The connection was registered with `credentials.request_api_access` using these details. The stored credential was verified live on Oct 30, 2026, with a list read and a create, read and delete round trip that left the store empty again. Reuse these details to reconnect:

```json
{
  "provider": "sharednotes",
  "auth_scheme": "api_key",
  "placement": "bearer_header",
  "api_hosts": ["sharednotes.minkenlai.workers.dev"]
}
```

- Reuse those details to reconnect. The host is the Workers subdomain from deploy, without any scheme or path.

- Before the first change in a conversation, prove access with a harmless read:

```text
python3 ~/workspace/custom-connectors/custom.sharednotes/bin/notes.py --host sharednotes.minkenlai.workers.dev list
```

## Credentials

- The registered connection holds the credential. Helpers import `/opt/muse/skills/custom-connector-setup/bin/dynamic_credentials.py`, which returns an `hsurr:` surrogate and places it where the provider reads the key. Muse swaps in the real credential only on an approved request to a registered host.

- Never put a key, token, password or cookie in this doc, a helper, a command argument, an environment variable or a log. Never ask the user to paste one in chat.

- Keep redirects disabled on authenticated requests.

- On a 401 or 403, check the request first. Confirm that the helper attached the credential, that the host is registered and that the placement and scopes match.

- Only when a request that carried the credential is still rejected, call `credentials.request_api_access` with the details above and `"reconnect": true`.

## List notes

- Lists notes newest first. This is a read and changes nothing.

```text
python3 ~/workspace/custom-connectors/custom.sharednotes/bin/notes.py --host <deployed-workers-host> list --limit 50
```

- The output has a `notes` array. Each note carries `id`, `title`, `body`, `created_by`, `created_at` and `updated_at`, and the deployed service also returns `snippet`, `content_type`, `is_archived` and `is_deleted`. Keep the `id` for later reads, updates and deletes.

## Read a note

- Reads one note by id. This is a read and changes nothing.

```text
python3 ~/workspace/custom-connectors/custom.sharednotes/bin/notes.py --host <deployed-workers-host> get <note-id>
```

## Create a note

- Creates a note and returns it with its new id. This is a write and is visible to everyone the service serves.

```text
python3 ~/workspace/custom-connectors/custom.sharednotes/bin/notes.py --host <deployed-workers-host> create --title "Title" --body "Body text"
```

- Confirm before creating, because the note is shared. The service records `created_by` from the key used.

## Update a note

- Updates the title or body of an existing note and returns it. This is a write and is visible to everyone the service serves.

```text
python3 ~/workspace/custom-connectors/custom.sharednotes/bin/notes.py --host <deployed-workers-host> update <note-id> --title "New title" --body "New body"
```

- Read the note first, so an update does not overwrite a newer edit. Omit a flag to leave that field unchanged.

## Delete a note

- Deletes a note by id. This is a write and cannot be undone by the service.

```text
python3 ~/workspace/custom-connectors/custom.sharednotes/bin/notes.py --host <deployed-workers-host> delete <note-id>
```

- Confirm the exact note with the user before deleting it.

## Recover from errors

- A 401 or 403 means the key is missing, wrong or not registered for this host. Check the credential and the host, then reconnect only as the Credentials section describes.

- A 404 means the note id does not exist. List notes to confirm the id before trying again.

- A 400 means the request body was not valid JSON or a required field was missing. Check the flags and try again.

- After a failed or timed-out change, check the current state with a read before trying again, because the first request may have completed.

## Limits

- Live calls against the deployed service are verified. A list read and a create, read and delete round trip both succeeded through the stored credential on Oct 30, 2026.

- The helper sends a browser-like User-Agent. Cloudflare's workers.dev front door rejects bare script user agents with error 1010, so a helper without that header fails before authentication.

- The service has no search and no sharing controls of its own, and anyone holding a valid key can read every note. Deletion removes a note from listings.

- The scaffold tool declines to run here because the connector docs already exist. The package was built by hand from its template and is complete.

## Related skills

- [Notes](/opt/muse/skills/knowledge-organization/SKILL.md)

- Use `muse.skill_search` to find other skills and `muse.connector_search` to find other connectors.
