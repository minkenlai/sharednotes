# Install this connector in another Muse

This package connects a Muse to the sharednotes service at
sharednotes.minkenlai.workers.dev. The service holds notes shared between
two people. Each person connects with their own API key.

## Steps for the Muse installing it

1. Place this whole folder at
   `~/workspace/custom-connectors/custom.sharednotes/` so that
   `CONNECTOR.md`, `connector.yaml` and `bin/notes.py` are all present.

2. Read `CONNECTOR.md` and follow it. It is the operating doc for the
   service: endpoints, auth, commands and recovery.

3. Register the credential with `credentials.request_api_access` using
   exactly these details:

```json
{
  "provider": "sharednotes",
  "auth_scheme": "api_key",
  "placement": "bearer_header",
  "api_hosts": ["sharednotes.minkenlai.workers.dev"]
}
```

4. The person installing enters their own API key on the secure entry
   page that call shows. Never ask for the key in chat, and never reuse
   another person's key. Each person has a separate key issued for the
   service.

5. Prove access with a harmless read before any change:

```text
python3 ~/workspace/custom-connectors/custom.sharednotes/bin/notes.py --host sharednotes.minkenlai.workers.dev list
```

## Notes for the installer

- The helper sends a browser-like User-Agent on purpose. Cloudflare's
  workers.dev front door rejects bare script user agents with error 1010,
  so do not remove that header.

- Do not edit the host, the provider slug or the placement. A call to an
  unlisted host is refused, and the placement cannot change after setup.
